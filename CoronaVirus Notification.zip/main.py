from plyer import notification
import requests
from bs4 import BeautifulSoup
from bs4 import Comment
import time



def notifyMe(title,message):
    notification.notify(
        title=title,
        message=message,
        app_icon="C:\\Users\\Ansh\\PycharmProjects\\First Project File\\CoronaVirusNotification\\virusimage.ico",
        timeout=15
    )

def getData(url):
    r=requests.get(url)
    return r.text


if __name__ == '__main__':

    while True:
        myHtmlData=getData("https://www.mohfw.gov.in/")

        soup = BeautifulSoup(myHtmlData, 'html.parser')
        # soup.prettify()

        data = soup.find_all('table')

        for d in data:
            s=d.find_all(string=lambda text: isinstance(text, Comment))
            for dat in s:
                comment_html_data=BeautifulSoup(dat,'html.parser')
                datainlist=""
                # tdlist=comment_html_data.find_all('td')
                for i in comment_html_data:
                    datainlist+=i.get_text()
                datainlist=datainlist[2:]

                itemList=datainlist.split("\n\n\n")

                states=['Gujarat','Chandigarh','Punjab']
                for item in itemList[0:35]:
                    dataList = item.split("\n")
                    if dataList[1] in states:
                        print(dataList)
                        nTitle='Cases of COVID-19'
                        nText=f'State {dataList[1]}\nIndian : {dataList[2]}\nForeign : {dataList[3]}\nDeaths : {dataList[4]}'
                        notifyMe(nTitle,nText)
                        time.sleep(2)

        time.sleep(3600)